*PADS-LIBRARY-PART-TYPES-V9*

XIAO_ESP32S3 DIP1529W75P254L2100H125Q14N I ANA 9 1 0 0 0
TIMESTAMP 2026.03.06.03.48.04
"Manufacturer_Name" Seeed Studio
"Manufacturer_Part_Number" XIAO ESP32S3
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Dev.kit: evaluation; u.FL antenna,prototype board; XIAO; PIN: 2x7
"Datasheet Link" https://files.seeedstudio.com/wiki/SeeedStudio-XIAO-ESP32S3/res/esp32-s3_datasheet.pdf
"Geometry.Height" 1.25mm
GATE 1 14 0
XIAO_ESP32S3
1 0 U GPIO01
2 0 U GPIO02
3 0 U GPIO03
4 0 U GPIO04
5 0 U GPIO05
6 0 U GPIO06
7 0 U GPIO43
14 0 U 5V
13 0 U GND
12 0 U 3V3
11 0 U GPIO09
10 0 U GPIO08
9 0 U GPIO07
8 0 U GPIO44

*END*
*REMARK* SamacSys ECAD Model
20345555/1945119/2.50/14/0/Transistor E-mode GaN (3-Pin)
